package org.iesalixar.daw2.dao;

import java.util.HashSet;
import java.util.Set;

import org.iesalixar.daw2.helper.MemoryData;
import org.iesalixar.daw2.model.Hospital;
import org.iesalixar.daw2.model.Surgeon;

public class HospitalDAOImpl{
	
	public static Set<Hospital> getHospitalsWithEqualNumberOfSurgeonsAndOperatingRooms() {
		if(!MemoryData.isLoaded)
			MemoryData.load();
		
		Set<Hospital> result = new HashSet<Hospital>();
		
		for(Hospital hospital:MemoryData.list_hospitals) {
			if(hospital.getSurgeons().size()==hospital.getOperatingRooms().size())
				result.add(hospital);
		}
		return result;
	}
	
	public static void createHospital(Hospital hospital) {}
	public static void addSurgeon(Surgeon surgeon, Hospital hospital) {}

	/**
	 * RestServer1: Hospital getHospitalByNameBySurgeon(String hospitalName,String surgeonName)
	 * @param surgeonLicense
	 * @param hospitalName
	 * @return
	 */
	public static Response getHospitalByNameBySurgeonLicense(String hospitalName,String surgeonLicense) {
		if(!MemoryData.isLoaded)
			MemoryData.load();
		for(Hospital hospital:MemoryData.list_hospitals) {
			if(hospital.getName().equals(hospitalName)) {
				for(Surgeon surgeon:hospital.getSurgeons()) {
					if(surgeon.getLicense().equals(surgeonLicense))
						return hospital;
				}
			}
		}
		return null;
	}
	
	

}
